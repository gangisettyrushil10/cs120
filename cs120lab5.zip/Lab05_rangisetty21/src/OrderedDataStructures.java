

import java.util.ArrayList;

public abstract class OrderedDataStructures<T> implements Iterable{
	
	
	public OrderedDataStructures() {
		
	}
	
	public OrderedDataStructures(ArrayList<T> values) {
		for(int i = 0; i < values.size(); i++) {
			T a = values.get(i);
			this.add(a);
		}
	}
	
	abstract T get(int i) throws OutOfBoundsException;
	
	abstract int add(T value);
	
	public int getSize() {
		return this.getSize();
	}
	
	public ArrayList<T> toArrayList(){
		ArrayList<T> L = new ArrayList<>();
		for(T value: L) {
			L.add(value);
		}
		return L;
	}
	
	public String toString() {
		String rtnString = "";
		ArrayList<T> NL = this.toArrayList();
		for(T value: NL) {
			rtnString += value;
		}
		return rtnString;
	}

	public boolean hasNext() {
		// TODO Auto-generated method stub
		return false;
	}

	public Object next() {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}