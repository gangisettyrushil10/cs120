import java.util.Iterator;





public class SortedLinkedList<T extends Comparable<T>> extends OrderedDataStructures<T> implements Iterator {
	private LinkedListNode<T> header;
	
	public SortedLinkedList() {
		header = null;
	}

	public int getSize() {
		int currentIndex = 0;
		if(header == null) {
			return currentIndex;
		} else {
			LinkedListNode<T> currentNode = header;
			while(currentNode.getNext() != null) {
				currentNode = currentNode.getNext();
				currentIndex++;
			}
		}
		return currentIndex;
	}
	
	public T get(int index) throws OutOfBoundsException {
		int currentIndex = 0;
		T rtnValue = null;
		if(header == null) {
			return null;
		} else if(index == 0) {
			rtnValue = header.getValue();
		} else if(index < 0 || index > this.getSize()) {
			throw new OutOfBoundsException("Out of Bounds");
		} else {
			LinkedListNode<T> currentNode = header;
			while(currentNode.getNext() != null && currentIndex < index) {
				currentIndex++;
				currentNode = currentNode.getNext();
			}
			if(currentIndex == index) {
				rtnValue = currentNode.getValue();
			}
		}
		return  rtnValue;
	}
	
	public int add(T value) {
		int currentIndex = 0;
		LinkedListNode<T> insertedNode = new LinkedListNode<>(value, null);
		if(header == null) {
			header = insertedNode;
		} else if(header.getValue().compareTo(value) > 0) {
			insertedNode.setNext(header);
			header = insertedNode;
		} else {
			LinkedListNode<T> currentNode = header;
			while(currentNode.getNext() != null && currentNode.getNext().getValue().compareTo(value) < 0) {
				currentIndex++;
				currentNode = currentNode.getNext();
			}
			insertedNode.setNext(currentNode.getNext());
			currentNode.setNext(insertedNode);
		}
		return currentIndex;
	}
	
	public T remove(T value) {
		T rtnValue = null;
		if(header == null) {
			return rtnValue;
		} else {
			LinkedListNode<T> currentNode = header;
			LinkedListNode<T> prevNode = null;
			while(currentNode.getNext() != null) {
				if(((Comparable<T>) currentNode.getValue()).compareTo(value) == 0){
					prevNode.setNext(currentNode.getNext());
					rtnValue = currentNode.getValue();
				}
				prevNode = currentNode;
				currentNode = currentNode.getNext();
			}
		}  
	return rtnValue;
		
	}
	
	public T getValue(T value) {
		T rtnValue = null;
		if(header == null) {
			return rtnValue;
		} else {
			LinkedListNode<T> currentNode = header;
			while(currentNode.getNext() != null) {
				if(((Comparable<T>) currentNode.getValue()).compareTo(value) == 0){
					rtnValue = currentNode.getValue();
				
			}
				currentNode = currentNode.getNext();
			}
		}
		return rtnValue;
	}
	
	public String toString() {
		if(header == null) {
			return "List is empty";
		} 
		LinkedListNode<T> currentNode = header;
		String rtnString = currentNode.getValue()+", ";
		while(currentNode.getNext()!=null) {
			currentNode = currentNode.getNext();
			rtnString += currentNode.getValue()+", ";
		}
		return rtnString;		
	}
		private class LinkedListNode<T> {
		
		private LinkedListNode<T> next;
		private T value;
		
		public LinkedListNode(T value, LinkedListNode<T> next) {
			this.value = value;
			this.next = next;
		}

		public LinkedListNode<T> getNext() {
			return next;
		}

		public void setNext(LinkedListNode<T> next) {
			this.next = next;
		}

		public T getValue() {
			return value;
		}

		public void setValue(T value) {
			this.value = value;
		}
		}

		@Override
		public Iterator<T> iterator() {
			Iterator<T> rtnIter = new Iterator<T>(){
				private LinkedListNode<T> current = header;
				@Override
				public boolean hasNext() {
					if (current!= null){
						return true;
					} else {
						return false;
					}
				}
				@Override
				public T next() {
					LinkedListNode<T> currentValue = current;
					current = current.getNext();
					return currentValue.getValue();
					}
				};
				return rtnIter;
		}


		
		
		@Override
		public boolean hasNext() {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public Object next() {
			// TODO Auto-generated method stub
			return null;
		}	
}

