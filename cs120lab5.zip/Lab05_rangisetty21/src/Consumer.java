
public class Consumer extends Thread {
	
	SynchronizedQueue<Integer> sq;
	int sqSize;
	int Delay;
	
	public Consumer(SynchronizedQueue<Integer> sq, int sqSize, int Delay) {
		super();
		this.sq = sq;
		this.sqSize = sqSize;
		this.Delay = Delay;
	}
	
	public void run(){
		int y;
		for(int i = 0; i < sqSize; i++) {
			if(sq.getSize() <= 0) {
				System.out.println("Queue is empty");
				this.run();
			}
			y = sq.pop();
			System.out.println("Removed: "+y+"Queue now contains: "+sq.toString());
			try {
				sleep(Delay);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}