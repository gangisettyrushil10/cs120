
public class Producer extends Thread {
	
	SynchronizedQueue<Integer> sq;
	int sqSize;
	int Delay;
	
	public Producer(SynchronizedQueue<Integer> sq, int sqSize, int Delay) {
		super();
		this.sq = sq;
		this.sqSize = sqSize;
		this.Delay = Delay;
	}
	
	public synchronized void produce() {
		for(int i = 0; i < sqSize; i++) {
			int x = (int) (Math.random()*1000);
			sq.push(x);
			System.out.println("Added: "+x+" Queue now contains: "+sq.toString());
			if(sq.getSize() > sqSize) {
				System.out.println("Queue is full");
			}
			try {
				sleep(Delay);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public void run(){
		this.produce();
	}
}
