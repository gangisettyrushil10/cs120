import java.util.Iterator;

public class DoublyLinkedList<T> extends OrderedDataStructures<T> implements Iterator{
	private DoublyLinkedListNode<T> header;
	private DoublyLinkedListNode<T> tail;
	
	public DoublyLinkedList() {
		header = null;
		tail = null;
	}
	
	public synchronized int getSize() {
		int currentIndex = 0;
		if(header == null) {
			return currentIndex;
		} else {
			DoublyLinkedListNode<T> currentNode = header;
			while(currentNode.getNext() != null) {
				currentIndex++;
				currentNode = currentNode.getNext();
			}
		}
		return currentIndex;
	}
	
	public synchronized T get(int index) throws OutOfBoundsException {
		int currentIndex = 0;
		T rtnValue = null;
		if(header == null) {
			return null;
		} else if(index == 0) {
			rtnValue = header.getValue();
		} else if(index < 0 || index > this.getSize()) {
			throw new OutOfBoundsException("Out of Bounds");
		} else {
			DoublyLinkedListNode<T> currentNode = header;
			while(currentNode.getNext() != null && currentIndex < index) {
				currentIndex++;
				currentNode = currentNode.getNext();
			}
			if(currentIndex == index) {
				rtnValue = currentNode.getValue();
			}
		}
		return  rtnValue;
	}
	
	public  synchronized T remove(int index) throws OutOfBoundsException{
		T rtnValue = null;
		int currentIndex = 0;
		if(header == null || index < 0) {
			throw new OutOfBoundsException("Out of Bounds");
		} else if (index==0) {
			rtnValue = header.getValue();
			header = header.getNext();
			header.setPrevious(null);
			return rtnValue;
		} else {
			DoublyLinkedListNode<T> currentNode = header;
			while(currentIndex < index && currentNode.getNext() != null) {
				currentIndex++;
				currentNode = currentNode.getNext();
			}
			if(currentIndex==index && currentNode.getNext()!=null) {
				DoublyLinkedListNode<T> nextNode = currentNode.getNext();
				DoublyLinkedListNode<T> prevNode = currentNode.getPrevious();
				rtnValue = currentNode.getValue();
				prevNode.setNext(nextNode);
				nextNode.setPrevious(prevNode);
				return rtnValue;
			} else if (currentIndex == index && currentNode.getNext() == null){
				DoublyLinkedListNode<T> prev = currentNode.getPrevious();
				tail = prev;
				rtnValue = currentNode.getValue();
				prev.setNext(null);
				return rtnValue;
			} else { 
				return rtnValue;
			}
		}
	}
	
	public synchronized int insert(T value, int index) throws OutOfBoundsException {
		int currentIndex = 0;
		if(index < 0) {
			throw new OutOfBoundsException("Out of Bounds");
		} else if(header == null) {
			header = new DoublyLinkedListNode<T>(value, null, null);
			tail = header;
			return 0;
		} else if(index == 0 && this.getSize() == 0) {
			header = new DoublyLinkedListNode<T> (value, header, null);
			tail = header;
		} else if(index == 0 && this.getSize() > 0){
			DoublyLinkedListNode<T> insertedNode = new DoublyLinkedListNode<>(value, header, null);
			header.setPrevious(insertedNode);
			header = insertedNode;
			
		} else {
			DoublyLinkedListNode<T> currentNode = header;
			DoublyLinkedListNode<T> previousNode = null;
			while(currentIndex < index && currentNode.getNext() != null) {
				currentNode = currentNode.getNext();
				currentIndex++;
			}
			previousNode = currentNode;
			DoublyLinkedListNode<T> insertedNode = new DoublyLinkedListNode<T>(value, previousNode, currentNode);
			insertedNode.setPrevious(previousNode);
			previousNode.setNext(insertedNode);
		}
		return currentIndex;
	}
	
	public synchronized int add(T value) {
		int currentIndex = 0;
		if(header == null) {
			header = new DoublyLinkedListNode<T>(value, null, null);
			return 0;
		} else {
			DoublyLinkedListNode<T> currentNode = header;
			while(currentNode.getNext() != null) {
				currentIndex++;
				currentNode = currentNode.getNext();
			}
			DoublyLinkedListNode<T> insertedNode = new DoublyLinkedListNode<T>(value, null, currentNode);
			currentNode.setNext(insertedNode);
		}
		return currentIndex;
	}
	
	public synchronized String toString() {
		if(header == null) {
			return "List is empty";
		} 
		DoublyLinkedListNode<T> currentNode = header;
		String rtnString = currentNode.getValue()+", ";
		while(currentNode.getNext()!=null) {
			currentNode = currentNode.getNext();
			rtnString += currentNode.getValue()+", ";
		}
		return rtnString;		
	}

	private class DoublyLinkedListNode<T> {
	private T value;
	private DoublyLinkedListNode<T> next;
	private DoublyLinkedListNode<T> previous;
	
	public DoublyLinkedListNode(T value, DoublyLinkedListNode<T> next, DoublyLinkedListNode<T> previous) {
		this.value = value;
		this.next = next;
		this.previous = previous;
	}
	
	public DoublyLinkedListNode<T> getPrevious() {
		return previous;
	}
	
	public void setPrevious (DoublyLinkedListNode<T> previous) {
		this.previous = previous;
	}
	
	public T getValue() {
		return value;
	}

	public void setValue(T value) {
		this.value = value;
	}

	public DoublyLinkedListNode<T> getNext() {
		return next;
	}

	public void setNext(DoublyLinkedListNode<T> next) {
		this.next = next;
	}
}

	@Override
	public Iterator<T> iterator() {
		Iterator<T> rtnIter = new Iterator<T>(){
			private DoublyLinkedListNode<T> current = header;
			@Override
			public boolean hasNext() {
				if (current!= null){
					return true;
				} else {
					return false;
				}
			}
			@Override
			public T next() {
				DoublyLinkedListNode<T> currentValue = current;
				current = current.getNext();
				return currentValue.getValue();
				}
			};
			return rtnIter;
	}


	
	
	@Override
	public boolean hasNext() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Object next() {
		// TODO Auto-generated method stub
		return null;
	}
}
