import java.util.Scanner;

public class Starter {
	public static void main(String[] args) {
	SynchronizedQueue<Integer> sq = new SynchronizedQueue<>();
	Scanner scan = new Scanner(System.in);
	
	int sqSize;
	int ProThreads;
	int ConThreads;
	int ProDelay;
	int ConDelay;
	
	System.out.println("Pleasae enter the size of the queue: ");
	sqSize = scan.nextInt();
	
	System.out.println("Please enter the number of producer threads: ");
	ProThreads = scan.nextInt();
	
	System.out.println("Please enter the number of consumer threads: ");
	ConThreads = scan.nextInt();
	
	System.out.println("Please enter the seconds of delay for the Producer: ");
	ProDelay = 1000 * scan.nextInt();
	
	System.out.println("Please enter the seconds of delay for the Consumer: ");
	ConDelay = 1000 *  scan.nextInt();
	
	Producer ProducerThreads[] = new Producer[ProThreads];
	Consumer ConsumerThreads[] = new Consumer[ConThreads];
	
	for (int i = 0; i < ProducerThreads.length; i++) {
		ProducerThreads [i] = new Producer (sq, sqSize, ProDelay);
		ProducerThreads [i].start();
	}
	
	for(int i = 0; i < ConsumerThreads.length; i++) {
		ConsumerThreads [i] = new Consumer(sq, sqSize, ProDelay);
		ConsumerThreads [i].start();
	}
	
	
	
 
	}
}
