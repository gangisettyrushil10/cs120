
public class OutOfBoundsException extends Exception {
	public OutOfBoundsException (String message) {
		super(message);
	}
}
